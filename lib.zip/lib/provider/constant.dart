

class Constants  {
  static const String clientId = 'AcLG1giUdKk7BW1lzvgW7516b85rVtG_8j-JLP5zGprrSbJZSP0syTrel6Wj9geAd_-61BeCwNw0nQMb';
  static const String secretKey = 'EDZfDWHtpJxImoPfPbPHF1BoMwSTNdnRfn150f6LWG2GmyDZUHEeBwe9Ds_YAkBWexb3snTJyolpWHP0';
  static const String returnURL= 'https://samplesite.com/return';
  static const String cancelURL = 'https://samplesite.com/cancel';

}